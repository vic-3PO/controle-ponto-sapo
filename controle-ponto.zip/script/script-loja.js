// Arquivo para gerenciar a loja de temas
document.addEventListener('DOMContentLoaded', () => {
    carregarTemaAtual();
});

// Temas disponíveis
const temas = {
    padrao: {
        nome: "Tema Padrão",
        corPrimaria: "#4b7d57",
        corSecundaria: "#a3d49f",
        corFundo: "#eef7e6",
        corGradiente: "linear-gradient(to bottom, #d4f3c7, #eaf9e0)",
        corTexto: "#3a5a40",
        corBotao: "#4CAF50",
        corBotaoHover: "#3a5a40",
        emoji: "🐸"
    },
    cinnamoroll: {
        nome: "Tema Cinnamoroll",
        corPrimaria: "#6eb5ff",
        corSecundaria: "#c9e3ff",
        corFundo: "#f0f8ff",
        corGradiente: "linear-gradient(to bottom, #c9e3ff, #f0f8ff)",
        corTexto: "#4682b4",
        corBotao: "#6eb5ff",
        corBotaoHover: "#4682b4",
        emoji: "☁️"
    },
    pompompurin: {
        nome: "Tema Pompompurin",
        corPrimaria: "#ffb347",
        corSecundaria: "#ffe0b2",
        corFundo: "#fff8e1",
        corGradiente: "linear-gradient(to bottom, #ffe0b2, #fff8e1)",
        corTexto: "#b25900",
        corBotao: "#ffb347",
        corBotaoHover: "#b25900",
        emoji: "🍮"
    }
};

// Função para aplicar o tema selecionado
function aplicarTema(temaNome) {
    if (!temas[temaNome]) return;
    
    const tema = temas[temaNome];
    
    // Criar ou atualizar o estilo personalizado
    let estiloTema = document.getElementById('tema-personalizado');
    if (!estiloTema) {
        estiloTema = document.createElement('style');
        estiloTema.id = 'tema-personalizado';
        document.head.appendChild(estiloTema);
    }
    
    // Aplicar as cores do tema
    estiloTema.textContent = `
        body {
            background-color: ${tema.corFundo};
            color: ${tema.corTexto};
        }
        
        header {
            background: ${tema.corGradiente};
            border-bottom: 2px solid ${tema.corSecundaria};
        }
        
        header h1 {
            color: ${tema.corPrimaria};
        }
        
        #config-horario, #sapo-status, #seletor-mes, .secao-jogos, .secao-quiz {
            background-color: ${tema.corSecundaria};
            border: 2px solid ${tema.corPrimaria};
        }
        
        .button {
            background-color: ${tema.corBotao};
        }
        
        .button:hover {
            background-color: ${tema.corBotaoHover};
        }
        
        #tabela-ponto thead {
            background-color: ${tema.corSecundaria};
            color: ${tema.corTexto};
        }
        
        #tabela-ponto th, #tabela-ponto td {
            border: 1px solid ${tema.corSecundaria};
        }
        
        footer {
            background-color: ${tema.corSecundaria};
            border-top: 2px solid ${tema.corPrimaria};
            color: ${tema.corPrimaria};
        }
        
        .quiz-tab.active {
            background: ${tema.corBotao};
        }
        
        .quiz-tab {
            background: ${tema.corSecundaria};
        }
    `;
    
    // Atualizar emojis no cabeçalho e rodapé
    document.querySelector('header h1').textContent = `${tema.emoji} Controle de Ponto ${tema.emoji}`;
    document.querySelector('footer p').textContent = `${tema.emoji} Feito com carinho por sapinhos no lago ${tema.emoji}`;
    
    // Atualizar botões na loja
    document.querySelectorAll('.tema-card button').forEach(btn => {
        btn.classList.remove('tema-ativo');
        btn.textContent = 'Aplicar';
    });
    
    const botaoAtivo = document.querySelector(`.tema-card[data-tema="${temaNome}"] button`);
    if (botaoAtivo) {
        botaoAtivo.classList.add('tema-ativo');
        botaoAtivo.textContent = 'Ativo';
    }
    
    // Salvar a preferência do usuário
    localStorage.setItem('tema-atual', temaNome);
}

// Função para carregar o tema salvo
function carregarTemaAtual() {
    const temaSalvo = localStorage.getItem('tema-atual') || 'padrao';
    aplicarTema(temaSalvo);
}
